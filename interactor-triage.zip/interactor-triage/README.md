# Interactor Triage

<!-- Replace USERNAME below with your GitHub username after you push. -->
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USERNAME/interactor-triage/blob/main/notebooks/interactor_triage.ipynb)

Structural triage for proximity-labeling candidate interactors. Rank a finalized
bait's candidate list by AlphaFold-Multimer interface confidence (ipTM) before
committing to co-IP — no PyTorch, and no local GPU required for most of the
pipeline.

`docs/index.html` is the project landing page (open it in a browser).

## Why

Proximity-labeling proteomics (BioID, TurboID, and related methods) identifies
proteins in the physical neighborhood of a bait, but even after filtering against
negative controls a finalized candidate list still mixes genuine interactors with
chronic background — abundant cytoskeletal and metabolic proteins that show up
near almost any bait. Before spending low-throughput validation on every
candidate, this tool asks a cheaper question first: *does a physically plausible
bound complex even exist between the bait and this candidate?* AlphaFold-Multimer's
ipTM (interface predicted TM-score) is a widely used computational proxy for that.

## Install

The core pipeline uses only the Python standard library (Python 3.8+), so there
is nothing to install to run `fetch-sequences`, `prep-msa`, and `rank`:

```bash
git clone <your-repo-url>
cd interactor-triage
chmod +x run.sh
```

The GPU-bound `fold` stage is delegated to ColabFold. Install it only if you want
to fold locally (`./run.sh fold --local`): `pip install "colabfold[alphafold]"`.

## Quickstart

```bash
./run.sh fetch-sequences --candidates sample_data/cd70_candidates.csv --bait CD70
./run.sh prep-msa
./run.sh fold          # packages an upload for the free ColabFold Colab notebook
./run.sh rank          # -> work/ranked_report.csv
```

Want to see the ranking/filtering immediately, without folding anything? Rank a
CSV of precomputed scores:

```bash
./run.sh rank --from-scores sample_data/sample_scores.csv
```

## Run it on a free GPU (Colab)

No local GPU? `notebooks/interactor_triage.ipynb` runs the whole pipeline
(fetch → paired queries → AlphaFold-Multimer → rank) on Colab's free GPU.
Open [colab.research.google.com](https://colab.research.google.com) → File →
Upload notebook → choose the `.ipynb`, set Runtime → GPU, edit the bait and
candidate list in the first cell, then Runtime → Run all. It downloads
`ranked_report.csv` at the end. The landing page's **Submit** button generates
a copy of this notebook prefilled with your inputs.

## Pipeline

| # | Stage | GPU | What it does |
|---|-------|-----|--------------|
| 01 | `fetch-sequences` | no | Pulls canonical FASTA for the bait and every candidate from UniProt's REST API. |
| 02 | `prep-msa` | no | Builds a paired `bait:candidate` query per candidate (`:`-joined chains) for ColabFold. |
| 03 | `fold` | yes | Predicts each complex with AlphaFold-Multimer via `colabfold_batch` (JAX). No local GPU? It packages `work/fold_job.zip` for the free ColabFold Colab notebook. |
| 04 | `rank` | no | Parses ipTM/pTM from the output and tiers every candidate into `ranked_report.csv`. |

All intermediate and final files live under `./work/` (override with `--work DIR`).

## Output tiers

Every candidate is tiered by ipTM, following the benchmark heuristics in
Evans et al. 2021 — a guideline, not a guarantee for any individual pair.

| Tier | ipTM |
|------|------|
| high-confidence | ≥ 0.80 |
| ambiguous | 0.60 – 0.80 |
| unlikely | < 0.60 |

`work/ranked_report.csv` columns: `candidate, bait, iptm, ptm, tier` (sorted by ipTM).

## Scope

Built for: narrowing a finalized proximity-labeling candidate list before
low-throughput validation; flagging candidates with no plausible predicted
interface; sanity-checking a known positive-control interactor.

Not for: statistical filtering of raw spectral counts (assumes an already-finalized
list); proof of interaction (high ipTM is plausibility, not evidence in cells);
replacing experimental validation.

## Built on

- Jumper, J. et al. Highly accurate protein structure prediction with AlphaFold. *Nature* 596, 583–589 (2021).
- Evans, R. et al. Protein complex prediction with AlphaFold-Multimer. *bioRxiv* (2021).
- Mirdita, M. et al. ColabFold: making protein structure prediction accessible to all. *Nature Methods* 19, 679–682 (2022).
- Steinegger, M. & Söding, J. MMseqs2 enables sensitive protein sequence searching. *Nature Biotechnology* 35, 1026–1028 (2017).
- The UniProt Consortium. UniProt: the Universal Protein Knowledgebase in 2023. *Nucleic Acids Research* 51, D523–D531 (2023).

MIT License.
