"""Interactor Triage — structural triage for proximity-labeling interactors.

Ranks a finalized proximity-labeling candidate list by AlphaFold-Multimer
interface confidence (ipTM) before committing to low-throughput validation.
"""

__version__ = "0.1.0"
