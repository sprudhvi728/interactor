"""Command-line entry point: dispatches the four pipeline stages."""

import argparse
import sys

from . import __version__, fetch_sequences, prep_msa, fold, rank


def build_parser():
    p = argparse.ArgumentParser(
        prog="interactor-triage",
        description="Structural triage for proximity-labeling interactors.",
    )
    p.add_argument("--version", action="version", version=f"interactor-triage {__version__}")
    p.add_argument("--work", default="work", help="working directory (default: ./work)")
    sub = p.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("fetch-sequences", help="pull FASTA for bait + candidates from UniProt")
    f.add_argument("--candidates", required=True, help="CSV/TSV/txt with one candidate per row")
    f.add_argument("--bait", required=True, help="bait gene name or UniProt accession")
    f.add_argument("--organism", default="9606", help="NCBI taxon id (default: 9606, human)")
    f.set_defaults(func=fetch_sequences.run)

    m = sub.add_parser("prep-msa", help="build paired bait:candidate queries for ColabFold")
    m.set_defaults(func=prep_msa.run)

    d = sub.add_parser("fold", help="predict complexes with AlphaFold-Multimer, or package a Colab job")
    d.add_argument("--local", action="store_true", help="run colabfold_batch locally if it is installed")
    d.add_argument("--model-type", default="alphafold2_multimer_v3", help="colabfold_batch --model-type")
    d.set_defaults(func=fold.run)

    r = sub.add_parser("rank", help="parse ipTM/pTM from fold output and tier candidates")
    r.add_argument("--from-scores", default=None,
                   help="optional CSV (candidate,iptm,ptm[,bait]) to rank without a predictions dir")
    r.add_argument("--out", default="ranked_report.csv", help="output report path")
    r.set_defaults(func=rank.run)

    return p


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
