"""Shared helpers: working-directory layout and manifest I/O."""

import json
import os


def work_paths(work):
    """Return the standard sub-paths under a working directory."""
    return {
        "root": work,
        "sequences": os.path.join(work, "sequences"),
        "queries": os.path.join(work, "queries"),
        "predictions": os.path.join(work, "predictions"),
        "manifest": os.path.join(work, "manifest.json"),
        "queries_manifest": os.path.join(work, "queries_manifest.json"),
    }


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def load_json(path):
    with open(path, "r") as fh:
        return json.load(fh)


def save_json(path, obj):
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2)


def read_fasta_sequence(path):
    """Return the single sequence in a FASTA file (concatenating wrapped lines)."""
    seq = []
    with open(path, "r") as fh:
        for line in fh:
            if line.startswith(">") or not line.strip():
                continue
            seq.append(line.strip())
    return "".join(seq)
