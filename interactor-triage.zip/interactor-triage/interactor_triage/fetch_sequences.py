"""Stage 01 — fetch-sequences.

Pull canonical FASTA for the bait and every candidate from UniProt's REST API.
No GPU, no third-party dependencies (stdlib urllib only).
"""

import csv
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

from .common import ensure_dir, save_json, work_paths

# UniProt accession pattern (per UniProt's own regex).
ACCESSION_RE = re.compile(
    r"^[OPQ][0-9][A-Z0-9]{3}[0-9]$|"
    r"^[A-NR-Z][0-9]([A-Z][A-Z0-9]{2}[0-9]){1,2}$"
)

BASE = "https://rest.uniprot.org/uniprotkb"


def _get(url, retries=3):
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "interactor-triage/0.1"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return ""
            last = exc
        except urllib.error.URLError as exc:
            last = exc
        time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"request failed: {url} ({last})")


def fetch_fasta(token, organism):
    """Resolve a gene name or accession to a FASTA record (empty string if not found)."""
    token = token.strip()
    if ACCESSION_RE.match(token):
        return _get(f"{BASE}/{token}.fasta")

    # gene name: prefer a reviewed (Swiss-Prot) entry for the organism
    q = urllib.parse.quote(f"gene_exact:{token} AND organism_id:{organism} AND reviewed:true")
    data = _get(f"{BASE}/search?query={q}&format=fasta&size=1")
    if data.strip():
        return data
    # fall back to any matching entry
    q2 = urllib.parse.quote(f"gene:{token} AND organism_id:{organism}")
    return _get(f"{BASE}/search?query={q2}&format=fasta&size=1")


def _parse_header(fasta):
    """Pull the accession out of a UniProt FASTA header (>sp|ACC|NAME ...)."""
    header = fasta.splitlines()[0] if fasta.strip() else ""
    m = re.match(r">\w+\|([^|]+)\|", header)
    return (m.group(1) if m else None), header.lstrip(">").strip()


def _sequence_length(fasta):
    return sum(len(l.strip()) for l in fasta.splitlines()[1:] if not l.startswith(">"))


def _read_candidate_list(path):
    tokens = []
    with open(path, newline="") as fh:
        sniff = fh.read(2048)
        fh.seek(0)
        delim = "\t" if "\t" in sniff and "," not in sniff else ","
        reader = csv.reader(fh, delimiter=delim)
        for i, row in enumerate(reader):
            if not row or not row[0].strip():
                continue
            first = row[0].strip()
            if i == 0 and re.search(r"gene|protein|candidate|uniprot|accession|id|name", first, re.I):
                continue  # header row
            tokens.append(first)
    return tokens


def _safe(name):
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)


def _write(seq_dir, token, fasta):
    path = os.path.join(seq_dir, f"{_safe(token)}.fasta")
    with open(path, "w") as fh:
        fh.write(fasta if fasta.endswith("\n") else fasta + "\n")
    acc, header = _parse_header(fasta)
    return {
        "query": token,
        "accession": acc,
        "header": header,
        "file": os.path.relpath(path, os.path.dirname(seq_dir)),
        "length": _sequence_length(fasta),
    }


def run(args):
    paths = work_paths(args.work)
    seq_dir = ensure_dir(paths["sequences"])
    ensure_dir(paths["root"])

    print(f"[fetch-sequences] bait={args.bait} organism={args.organism}")
    bait_fasta = fetch_fasta(args.bait, args.organism)
    if not bait_fasta.strip():
        print(f"  ! could not resolve bait '{args.bait}' on UniProt", file=sys.stderr)
        return 1
    bait_rec = _write(seq_dir, args.bait, bait_fasta)
    print(f"  bait {args.bait} -> {bait_rec['accession']} ({bait_rec['length']} aa)")

    candidates = _read_candidate_list(args.candidates)
    print(f"[fetch-sequences] {len(candidates)} candidates from {args.candidates}")

    records, missing = [], []
    for token in candidates:
        fasta = fetch_fasta(token, args.organism)
        if not fasta.strip():
            missing.append(token)
            print(f"  ! {token}: not found")
            continue
        rec = _write(seq_dir, token, fasta)
        records.append(rec)
        print(f"  {token} -> {rec['accession']} ({rec['length']} aa)")

    save_json(paths["manifest"], {
        "organism": args.organism,
        "bait": bait_rec,
        "candidates": records,
        "missing": missing,
    })
    print(f"[fetch-sequences] wrote {len(records)} sequences + manifest "
          f"({len(missing)} missing) -> {paths['manifest']}")
    return 0
