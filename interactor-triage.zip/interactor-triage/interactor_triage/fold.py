"""Stage 03 — fold  (the only GPU-bound stage).

Predicts each bait:candidate complex with AlphaFold-Multimer via colabfold_batch
(JAX, not PyTorch).

  * --local : if colabfold_batch is on PATH, run it into work/predictions/.
  * default : package the queries into work/fold_job.zip together with
              instructions for the free official ColabFold Colab notebook,
              so no local GPU is required.
"""

import os
import shutil
import subprocess
import sys
import zipfile

from .common import ensure_dir, work_paths

COLAB_INSTRUCTIONS = """\
# Running the fold step on free Colab

1. Open the official ColabFold notebook:
   https://colab.research.google.com/github/sokrypton/ColabFold/blob/main/AlphaFold2.ipynb
2. Runtime -> Change runtime type -> GPU.
3. Upload the query FASTA files from this archive (the `queries/` folder), or
   use the batch cell and point it at an uploaded copy of `queries/`.
4. Set model type to `alphafold2_multimer_v3` and enable the MMseqs2 (paired) MSA.
5. Run all cells. When it finishes, download the results.
6. Unzip the downloaded results into `work/predictions/` in this project.
7. Back here, run:  ./run.sh rank

Each query is a single FASTA record whose two chains are separated by ':' —
AlphaFold-Multimer reads that as a complex.
"""


def _query_files(q_dir):
    if not os.path.isdir(q_dir):
        raise SystemExit("no queries/ — run `prep-msa` first")
    return sorted(f for f in os.listdir(q_dir) if f.endswith(".fasta"))


def _run_local(args, paths, files):
    exe = shutil.which("colabfold_batch")
    if not exe:
        print("  ! colabfold_batch not found on PATH; falling back to packaging a Colab job",
              file=sys.stderr)
        return _package(paths, files)
    out = ensure_dir(paths["predictions"])
    cmd = [exe, "--model-type", args.model_type, paths["queries"], out]
    print(f"[fold] running: {' '.join(cmd)}")
    return subprocess.call(cmd)


def _package(paths, files):
    zip_path = os.path.join(paths["root"], "fold_job.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.write(os.path.join(paths["queries"], f), arcname=f"queries/{f}")
        zf.writestr("COLAB_INSTRUCTIONS.md", COLAB_INSTRUCTIONS)
    ensure_dir(paths["predictions"])
    print(f"[fold] packaged {len(files)} queries -> {zip_path}")
    print("[fold] no local GPU needed: upload it to the free ColabFold notebook.")
    print("       (see COLAB_INSTRUCTIONS.md inside the archive)")
    return 0


def run(args):
    paths = work_paths(args.work)
    files = _query_files(paths["queries"])
    print(f"[fold] {len(files)} paired queries")
    if args.local:
        return _run_local(args, paths, files)
    return _package(paths, files)
