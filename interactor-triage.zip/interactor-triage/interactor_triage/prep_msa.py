"""Stage 02 — prep-msa.

Build one paired bait:candidate query per candidate, in the ':'-joined chain
format ColabFold uses for complexes. colabfold_batch then generates the paired
MSA via the public MMseqs2 server at fold time — the same free service the
official ColabFold notebook uses internally.
"""

import os

from .common import ensure_dir, load_json, read_fasta_sequence, save_json, work_paths


def run(args):
    paths = work_paths(args.work)
    if not os.path.exists(paths["manifest"]):
        raise SystemExit("no manifest.json — run `fetch-sequences` first")

    manifest = load_json(paths["manifest"])
    seq_root = paths["root"]
    q_dir = ensure_dir(paths["queries"])

    bait = manifest["bait"]
    bait_seq = read_fasta_sequence(os.path.join(seq_root, bait["file"]))
    bait_name = bait["query"]

    queries = []
    for cand in manifest["candidates"]:
        cand_seq = read_fasta_sequence(os.path.join(seq_root, cand["file"]))
        name = f"{cand['query']}__on__{bait_name}"
        qpath = os.path.join(q_dir, f"{_safe(cand['query'])}.fasta")
        with open(qpath, "w") as fh:
            # single record, chains separated by ':' -> AlphaFold-Multimer complex
            fh.write(f">{name}\n{bait_seq}:{cand_seq}\n")
        queries.append({
            "candidate": cand["query"],
            "bait": bait_name,
            "name": name,
            "file": os.path.relpath(qpath, seq_root),
            "length": len(bait_seq) + len(cand_seq),
        })
        print(f"  {name}  ({len(bait_seq)}+{len(cand_seq)} aa)")

    save_json(paths["queries_manifest"], {"bait": bait_name, "queries": queries})
    print(f"[prep-msa] wrote {len(queries)} paired queries -> {paths['queries']}")
    return 0


def _safe(name):
    import re
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)
