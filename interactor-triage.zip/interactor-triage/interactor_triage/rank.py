"""Stage 04 — rank  (the filtering step).

Parse ipTM / pTM from the AlphaFold-Multimer output and tier every candidate
into a ranked report. Tier thresholds follow the benchmark heuristics in
Evans et al. 2021 — a guideline, not a guarantee for any individual pair.
"""

import csv
import glob
import json
import os
import re

from .common import load_json, work_paths

# ipTM tier thresholds (Evans et al. 2021)
TIER_HIGH = 0.80
TIER_AMBIGUOUS = 0.60


def tier_for(iptm):
    if iptm >= TIER_HIGH:
        return "high-confidence"
    if iptm >= TIER_AMBIGUOUS:
        return "ambiguous"
    return "unlikely"


def _candidate_from_filename(fname):
    """colabfold writes '<query>_scores_rank_00X_...json'; strip back to <query>."""
    base = os.path.basename(fname)
    return re.split(r"_scores_rank_", base)[0]


def _parse_predictions(pred_dir):
    """Return {candidate_query: {'iptm':.., 'ptm':..}} from the top-ranked model."""
    if not os.path.isdir(pred_dir):
        return {}
    # prefer the rank_001 (best) score files; fall back to any json with iptm
    files = sorted(glob.glob(os.path.join(pred_dir, "**", "*_scores_rank_001_*.json"), recursive=True))
    if not files:
        files = sorted(glob.glob(os.path.join(pred_dir, "**", "*.json"), recursive=True))
    out = {}
    for path in files:
        try:
            data = load_json(path)
        except (ValueError, OSError):
            continue
        if "iptm" not in data:
            continue
        query = _candidate_from_filename(path)
        # the query name is '<candidate>__on__<bait>'; keep the candidate part
        cand = query.split("__on__")[0]
        if cand in out:
            continue  # already have the best-ranked model for this candidate
        out[cand] = {"iptm": float(data["iptm"]), "ptm": float(data.get("ptm", 0.0))}
    return out


def _parse_scores_csv(path):
    out, bait = {}, None
    with open(path, newline="") as fh:
        reader = csv.DictReader(fh)
        norm = {k.lower().strip(): k for k in (reader.fieldnames or [])}
        for row in reader:
            cand = row[norm["candidate"]].strip()
            out[cand] = {
                "iptm": float(row[norm["iptm"]]),
                "ptm": float(row[norm.get("ptm", norm.get("iptm"))]),
            }
            if "bait" in norm and row[norm["bait"]].strip():
                bait = row[norm["bait"]].strip()
    return out, bait


def run(args):
    paths = work_paths(args.work)

    bait = "bait"
    if os.path.exists(paths["manifest"]):
        try:
            bait = load_json(paths["manifest"])["bait"]["query"]
        except (KeyError, ValueError):
            pass

    if args.from_scores:
        scores, csv_bait = _parse_scores_csv(args.from_scores)
        bait = csv_bait or bait
        source = args.from_scores
    else:
        scores = _parse_predictions(paths["predictions"])
        source = paths["predictions"]

    if not scores:
        raise SystemExit(f"no scores found in {source} — run `fold` (and download results) first")

    rows = []
    for cand, s in scores.items():
        rows.append({
            "candidate": cand,
            "bait": bait,
            "iptm": round(s["iptm"], 4),
            "ptm": round(s["ptm"], 4),
            "tier": tier_for(s["iptm"]),
        })
    rows.sort(key=lambda r: r["iptm"], reverse=True)

    out_path = os.path.join(paths["root"], args.out) if not os.path.isabs(args.out) else args.out
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with open(out_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["candidate", "bait", "iptm", "ptm", "tier"])
        writer.writeheader()
        writer.writerows(rows)

    counts = {"high-confidence": 0, "ambiguous": 0, "unlikely": 0}
    for r in rows:
        counts[r["tier"]] += 1

    print(f"\n  bait: {bait}   candidates ranked: {len(rows)}")
    print(f"  {'candidate':<16}{'ipTM':>7}{'pTM':>7}   tier")
    print("  " + "-" * 44)
    for r in rows:
        print(f"  {r['candidate']:<16}{r['iptm']:>7.3f}{r['ptm']:>7.3f}   {r['tier']}")
    print("  " + "-" * 44)
    print(f"  high-confidence: {counts['high-confidence']}   "
          f"ambiguous: {counts['ambiguous']}   unlikely: {counts['unlikely']}")
    print(f"\n[rank] wrote {out_path}")
    return 0
