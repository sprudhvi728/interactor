#!/usr/bin/env bash
# Thin wrapper around the interactor_triage CLI so stages can be called as
#   ./run.sh fetch-sequences --candidates ... --bait ...
set -euo pipefail
cd "$(dirname "$0")"
exec python3 -m interactor_triage.cli "$@"
